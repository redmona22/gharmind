import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.api.deps import ADMINS, CurrentUser, get_db, require_roles
from app.core.audit import audit
from app.core.security import hash_password
from app.db.models import User
from app.schemas.auth import UserCreateIn

router = APIRouter(tags=["users"])


def _out(u: User) -> dict:
    return {"id": str(u.id), "email": u.email, "name": u.name, "role": u.role,
            "active": u.active, "mfa_enrolled": u.mfa_secret is not None}


@router.get("")
def list_users(user: CurrentUser = Depends(require_roles(*ADMINS)), s=Depends(get_db)):
    rows = s.execute(select(User).where(User.tenant_id == user.tenant_id).order_by(User.name)).scalars().all()
    return {"items": [_out(u) for u in rows]}


@router.post("", status_code=201)
def create_user(body: UserCreateIn, user: CurrentUser = Depends(require_roles(*ADMINS)), s=Depends(get_db)):
    if body.role == "owner" and user.role != "owner":
        raise HTTPException(403, "only an owner can create another owner")
    try:
        pw_hash = hash_password(body.password)
    except ValueError as e:
        raise HTTPException(422, str(e))
    u = User(tenant_id=user.tenant_id, email=body.email, name=body.name, role=body.role, password_hash=pw_hash)
    s.add(u)
    try:
        s.flush()
    except IntegrityError:
        raise HTTPException(409, "a user with this email already exists")
    audit(s, user.tenant_id, str(user.id), "user_created", {"user_id": str(u.id), "role": body.role})
    return _out(u)


@router.post("/{user_id}/deactivate")
def deactivate_user(user_id: uuid.UUID, user: CurrentUser = Depends(require_roles(*ADMINS)), s=Depends(get_db)):
    """Instant offboarding: their token stops working on the very next request."""
    if user_id == user.id:
        raise HTTPException(400, "you cannot deactivate yourself")
    u = s.execute(select(User).where(User.id == user_id, User.tenant_id == user.tenant_id)).scalar_one_or_none()
    if u is None:
        raise HTTPException(404, "not found")
    if u.role == "owner" and user.role != "owner":
        raise HTTPException(403, "only an owner can deactivate an owner")
    u.active = False
    audit(s, user.tenant_id, str(user.id), "user_deactivated", {"user_id": str(u.id)})
    return _out(u)
