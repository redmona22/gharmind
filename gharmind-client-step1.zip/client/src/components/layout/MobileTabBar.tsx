import { NavLink } from "react-router-dom";

import { useAuth } from "../../hooks/useAuth";
import { cn } from "../../lib/cn";
import { navItems } from "./Sidebar";

export default function MobileTabBar() {
  const { user } = useAuth();
  const items = navItems.filter((i) => !i.roles || (user && i.roles.includes(user.role)));
  return (
    <nav className="flex border-t border-charcoal-800 bg-charcoal-950 md:hidden">
      {items.map((i) => (
        <NavLink
          key={i.to}
          to={i.to}
          className={({ isActive }) =>
            cn("flex-1 py-3 text-center text-sm font-medium", isActive ? "text-brand-500" : "text-charcoal-200")
          }
        >
          {i.label}
        </NavLink>
      ))}
    </nav>
  );
}
