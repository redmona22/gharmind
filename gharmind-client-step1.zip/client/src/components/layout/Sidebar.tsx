import { NavLink } from "react-router-dom";

import { useAuth } from "../../hooks/useAuth";
import { cn } from "../../lib/cn";
import type { Role } from "../../types/user";
import Button from "../ui/Button";

export const navItems: { to: string; label: string; roles?: Role[] }[] = [
  { to: "/leads", label: "Leads" },
  { to: "/listings", label: "Listings" },
  { to: "/team", label: "Team", roles: ["admin", "owner"] },
];

export default function Sidebar() {
  const { user, signOut } = useAuth();
  const items = navItems.filter((i) => !i.roles || (user && i.roles.includes(user.role)));
  return (
    <aside className="hidden w-60 shrink-0 flex-col bg-charcoal-950 text-white md:flex">
      <div className="flex items-center gap-2 px-5 py-5 text-lg font-semibold">
        <span className="inline-block h-3 w-3 rounded-full bg-brand-500" />
        Gharmind
      </div>
      <nav className="flex-1 space-y-1 px-3">
        {items.map((i) => (
          <NavLink
            key={i.to}
            to={i.to}
            className={({ isActive }) =>
              cn(
                "block rounded-md px-3 py-2 text-sm font-medium",
                isActive ? "bg-charcoal-800 text-brand-500" : "text-charcoal-200 hover:bg-charcoal-900",
              )
            }
          >
            {i.label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-charcoal-800 p-4">
        <p className="truncate text-sm font-medium">{user?.name}</p>
        <p className="mb-3 text-xs capitalize text-charcoal-400">{user?.role}</p>
        <Button variant="secondary" className="w-full" onClick={signOut}>
          Log out
        </Button>
      </div>
    </aside>
  );
}
