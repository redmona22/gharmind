import { Outlet } from "react-router-dom";

import MobileTabBar from "./MobileTabBar";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";

export default function AppShell() {
  return (
    <div className="flex h-screen flex-col md:flex-row">
      <Sidebar />
      <TopBar />
      <main className="min-h-0 min-w-0 flex-1 overflow-hidden">
        <Outlet />
      </main>
      <MobileTabBar />
    </div>
  );
}
