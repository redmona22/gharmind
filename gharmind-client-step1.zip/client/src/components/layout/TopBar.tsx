import { useAuth } from "../../hooks/useAuth";
import Button from "../ui/Button";

/** Mobile only: the sidebar holds these on larger screens. */
export default function TopBar() {
  const { signOut } = useAuth();
  return (
    <header className="flex items-center justify-between bg-charcoal-950 px-4 py-3 text-white md:hidden">
      <span className="flex items-center gap-2 font-semibold">
        <span className="inline-block h-3 w-3 rounded-full bg-brand-500" />
        Gharmind
      </span>
      <Button variant="secondary" className="h-8 px-3" onClick={signOut}>
        Log out
      </Button>
    </header>
  );
}
