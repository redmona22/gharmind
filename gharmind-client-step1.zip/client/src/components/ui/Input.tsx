import { useId, type InputHTMLAttributes } from "react";

import { cn } from "../../lib/cn";

export default function Input({
  label,
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  const id = useId();
  return (
    <div>
      {label && (
        <label htmlFor={id} className="mb-1 block text-sm font-medium text-charcoal-800">
          {label}
        </label>
      )}
      <input
        id={id}
        {...props}
        className={cn(
          "h-10 w-full rounded-md border border-charcoal-200 bg-white px-3 text-sm placeholder:text-charcoal-400",
          "disabled:bg-charcoal-50",
          className,
        )}
      />
    </div>
  );
}
