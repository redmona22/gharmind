import type { ButtonHTMLAttributes } from "react";

import { cn } from "../../lib/cn";

type Variant = "primary" | "secondary" | "ghost" | "danger";

const styles: Record<Variant, string> = {
  // Dark text on orange: white on #F97316 is too low-contrast for small text.
  primary: "bg-brand-500 text-charcoal-950 font-semibold hover:bg-brand-600",
  secondary: "border border-charcoal-200 bg-white text-charcoal-950 font-medium hover:bg-charcoal-50",
  ghost: "text-charcoal-600 font-medium hover:bg-charcoal-200/50",
  danger: "bg-danger text-white font-semibold hover:bg-red-700",
};

export default function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        "inline-flex h-10 items-center justify-center rounded-md px-4 text-sm transition-colors",
        "disabled:cursor-not-allowed disabled:opacity-50",
        styles[variant],
        className,
      )}
    />
  );
}
