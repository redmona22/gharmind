import type { ReactNode } from "react";

import { cn } from "../../lib/cn";

export type Tone = "green" | "amber" | "red" | "grey" | "orange" | "blue";

const tones: Record<Tone, string> = {
  green: "bg-green-100 text-green-800",
  amber: "bg-amber-100 text-amber-800",
  red: "bg-red-100 text-red-800",
  grey: "bg-charcoal-200 text-charcoal-800",
  orange: "bg-brand-100 text-brand-text",
  blue: "bg-blue-100 text-blue-800",
};

export default function Badge({ tone = "grey", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium", tones[tone])}>
      {children}
    </span>
  );
}
