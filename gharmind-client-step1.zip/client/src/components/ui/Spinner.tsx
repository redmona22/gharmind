export default function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-2 p-6 text-sm text-charcoal-600">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-charcoal-200 border-t-brand-500" />
      {label}...
    </div>
  );
}
