import { cn } from "../../lib/cn";
import { clock } from "../../lib/format";
import type { ChatMessage } from "../../types/lead";

const LABEL: Record<string, string> = { client: "Customer", agent: "AI assistant", human: "Team" };

export default function MessageBubble({ m }: { m: ChatMessage }) {
  const fromCustomer = m.sender === "client";
  return (
    <div className={cn("flex", fromCustomer ? "justify-start" : "justify-end")}>
      <div
        className={cn(
          "max-w-[80%] rounded-lg px-3 py-2 text-sm",
          fromCustomer && "border border-charcoal-200 bg-white",
          m.sender === "agent" && "bg-brand-100",
          m.sender === "human" && "bg-charcoal-900 text-white",
        )}
      >
        <p className={cn("mb-0.5 text-xs", m.sender === "human" ? "text-charcoal-200" : "text-charcoal-600")}>
          {LABEL[m.sender] ?? m.sender} · {clock(m.created_at)}
        </p>
        <p className="whitespace-pre-wrap break-words">{m.content}</p>
      </div>
    </div>
  );
}
