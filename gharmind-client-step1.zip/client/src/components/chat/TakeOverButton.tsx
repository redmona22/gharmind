import type { ConversationStatus } from "../../types/lead";
import Button from "../ui/Button";

export default function TakeOverButton({
  status, busy, onTakeOver, onRelease,
}: {
  status: ConversationStatus | undefined;
  busy: boolean;
  onTakeOver: () => void;
  onRelease: () => void;
}) {
  if (status === "human") {
    return <Button variant="secondary" disabled={busy} onClick={onRelease}>Hand back to AI</Button>;
  }
  return <Button disabled={busy || !status} onClick={onTakeOver}>Take over</Button>;
}
