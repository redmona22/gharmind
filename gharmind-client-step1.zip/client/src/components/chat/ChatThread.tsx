import { useEffect, useRef } from "react";

import type { ChatMessage } from "../../types/lead";
import MessageBubble from "./MessageBubble";

export default function ChatThread({ messages }: { messages: ChatMessage[] }) {
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    end.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  return (
    <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-charcoal-50 p-4">
      {messages.length === 0 && <p className="text-center text-sm text-charcoal-600">No messages yet.</p>}
      {messages.map((m) => (
        <MessageBubble key={m.id} m={m} />
      ))}
      <div ref={end} />
    </div>
  );
}
