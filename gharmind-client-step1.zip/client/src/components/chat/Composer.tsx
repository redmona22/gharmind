import { useRef, useState } from "react";

import { errorText } from "../../api/client";
import { newId } from "../../lib/format";
import Button from "../ui/Button";

export default function Composer({
  enabled, hint, onSend,
}: {
  enabled: boolean;
  hint: string;
  onSend: (text: string, clientMessageId: string) => Promise<void>;
}) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // The same text keeps the same id, so a retry after an error can never send twice.
  const pending = useRef<{ text: string; id: string } | null>(null);

  async function submit() {
    const t = text.trim();
    if (!t || sending || !enabled) return;
    if (!pending.current || pending.current.text !== t) pending.current = { text: t, id: newId() };
    setSending(true);
    setError(null);
    try {
      await onSend(t, pending.current.id);
      pending.current = null;
      setText("");
    } catch (e) {
      setError(errorText(e));
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="border-t border-charcoal-200 bg-white p-3">
      {error && <p role="alert" className="mb-2 text-sm text-danger">{error}</p>}
      <div className="flex items-end gap-2">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              submit();
            }
          }}
          disabled={!enabled || sending}
          rows={2}
          maxLength={4000}
          placeholder={enabled ? "Type a reply. Enter sends, Shift+Enter adds a line." : hint}
          className="min-h-[2.5rem] flex-1 resize-none rounded-md border border-charcoal-200 px-3 py-2 text-sm disabled:bg-charcoal-50"
        />
        <Button onClick={submit} disabled={!enabled || sending || !text.trim()}>
          {sending ? "Sending..." : "Send"}
        </Button>
      </div>
    </div>
  );
}
