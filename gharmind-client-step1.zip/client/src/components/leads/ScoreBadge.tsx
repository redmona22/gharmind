import Badge from "../ui/Badge";

export default function ScoreBadge({ score }: { score: number }) {
  // The label is always shown, so colour is never the only signal.
  const tier = score >= 70 ? { label: "Hot", tone: "green" as const }
    : score >= 40 ? { label: "Warm", tone: "amber" as const }
    : { label: "Cold", tone: "grey" as const };
  return <Badge tone={tier.tone}>{tier.label} {score}</Badge>;
}
