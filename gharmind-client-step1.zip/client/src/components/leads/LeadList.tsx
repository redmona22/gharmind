import type { LeadItem } from "../../types/lead";
import Spinner from "../ui/Spinner";
import LeadCard from "./LeadCard";

export default function LeadList({
  items, loading, error, selectedId, onSelect,
}: {
  items: LeadItem[];
  loading: boolean;
  error: string | null;
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  if (error && items.length === 0) return <p role="alert" className="p-4 text-sm text-danger">{error}</p>;
  if (loading && items.length === 0) return <Spinner label="Loading leads" />;
  if (items.length === 0) {
    return (
      <p className="p-6 text-center text-sm text-charcoal-600">
        No leads to show. New customer messages appear here.
      </p>
    );
  }
  return (
    <div>
      {items.map((l) => (
        <LeadCard key={l.id} lead={l} selected={l.id === selectedId} onSelect={() => onSelect(l.id)} />
      ))}
    </div>
  );
}
