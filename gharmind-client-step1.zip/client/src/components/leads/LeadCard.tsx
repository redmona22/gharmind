import { cn } from "../../lib/cn";
import { timeAgo } from "../../lib/format";
import type { LeadItem } from "../../types/lead";
import ScoreBadge from "./ScoreBadge";
import StatusChip from "./StatusChip";

const WHO: Record<string, string> = { client: "", agent: "AI: ", human: "Team: " };

export default function LeadCard({
  lead, selected, onSelect,
}: { lead: LeadItem; selected: boolean; onSelect: () => void }) {
  const m = lead.last_message;
  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "block w-full border-b border-charcoal-200 px-4 py-3 text-left hover:bg-charcoal-50",
        selected && "bg-brand-100/60",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="truncate font-medium">{lead.name || lead.phone}</span>
        <ScoreBadge score={lead.lead_score} />
      </div>
      <div className="mt-1 flex items-center gap-2">
        <StatusChip status={lead.conversation_status} />
        {m && <span className="text-xs text-charcoal-400">{timeAgo(m.at)}</span>}
      </div>
      {m && <p className="mt-1 truncate text-sm text-charcoal-600">{(WHO[m.sender] ?? "") + m.content}</p>}
    </button>
  );
}
