import type { OpenHandoff } from "../../types/lead";

export default function HandoffBanner({ handoffs }: { handoffs: OpenHandoff[] }) {
  if (handoffs.length === 0) return null;
  const h = handoffs[0];
  return (
    <div className="border-l-4 border-brand-500 bg-brand-100 px-4 py-3 text-sm">
      <p className="font-semibold text-charcoal-950">
        Needs a human: {h.reason.replace(/_/g, " ")}
      </p>
      <details className="mt-1">
        <summary className="cursor-pointer text-brand-text">Summary for you</summary>
        <p className="mt-2 whitespace-pre-wrap text-charcoal-800">{h.summary}</p>
      </details>
    </div>
  );
}
