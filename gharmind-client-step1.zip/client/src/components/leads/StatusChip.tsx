import type { ConversationStatus } from "../../types/lead";
import Badge from "../ui/Badge";

export default function StatusChip({ status }: { status: ConversationStatus | null | undefined }) {
  if (status === "human") return <Badge tone="orange">Human handling</Badge>;
  if (status === "agent") return <Badge tone="blue">AI handling</Badge>;
  if (status === "closed") return <Badge tone="grey">Closed</Badge>;
  return null;
}
