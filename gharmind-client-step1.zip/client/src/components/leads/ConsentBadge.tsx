import Badge from "../ui/Badge";

export default function ConsentBadge({ status }: { status: string }) {
  if (status === "opted_out") return <Badge tone="red">Opted out: do not message</Badge>;
  if (status === "opted_in") return <Badge tone="green">Opted in</Badge>;
  return <Badge tone="grey">No consent record</Badge>;
}
