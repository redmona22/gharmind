import { useAuth } from "../../hooks/useAuth";
import { formatINR } from "../../lib/format";
import type { LeadDetail } from "../../types/lead";
import ConsentBadge from "./ConsentBadge";
import ScoreBadge from "./ScoreBadge";

const LABELS: Record<string, string> = {
  purpose: "Purpose", budget_min: "Budget from", budget_max: "Budget up to",
  location_pref: "Area", bhk: "BHK", timeline: "Timeline", financing: "Financing",
};

function show(key: string, value: string | number): string {
  if (key.startsWith("budget")) return formatINR(Number(value));
  return String(value);
}

export default function ContactProfile({ lead }: { lead: LeadDetail }) {
  const { user } = useAuth();
  const entries = Object.entries(lead.qualification ?? {});
  const assigned = lead.assigned_user_id === user?.id ? "You"
    : lead.assigned_user_id ? "A team member" : "Unassigned";
  return (
    <div className="space-y-4 p-4 text-sm">
      <div>
        <h2 className="text-base font-semibold">{lead.name || "Unknown name"}</h2>
        <p className="text-charcoal-600">{lead.phone}</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <ScoreBadge score={lead.lead_score} />
          <ConsentBadge status={lead.consent_status} />
        </div>
      </div>

      <dl className="space-y-1">
        <div className="flex justify-between"><dt className="text-charcoal-600">Language</dt><dd className="uppercase">{lead.language}</dd></div>
        <div className="flex justify-between"><dt className="text-charcoal-600">Source</dt><dd>{lead.source || "-"}</dd></div>
        <div className="flex justify-between"><dt className="text-charcoal-600">Assigned to</dt><dd>{assigned}</dd></div>
      </dl>

      <div>
        <h3 className="mb-1 font-semibold">What they want</h3>
        {entries.length === 0 ? (
          <p className="text-charcoal-600">Nothing recorded yet.</p>
        ) : (
          <dl className="space-y-1">
            {entries.map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3">
                <dt className="text-charcoal-600">{LABELS[k] ?? k}</dt>
                <dd className="text-right">{show(k, v)}</dd>
              </div>
            ))}
          </dl>
        )}
      </div>
    </div>
  );
}
