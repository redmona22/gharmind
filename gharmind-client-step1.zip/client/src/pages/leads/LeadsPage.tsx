import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { errorText } from "../../api/client";
import { listMessages, release, sendMessage, takeover } from "../../api/conversations";
import { getLead, listLeads } from "../../api/leads";
import ChatThread from "../../components/chat/ChatThread";
import Composer from "../../components/chat/Composer";
import TakeOverButton from "../../components/chat/TakeOverButton";
import ContactProfile from "../../components/leads/ContactProfile";
import HandoffBanner from "../../components/leads/HandoffBanner";
import LeadList from "../../components/leads/LeadList";
import StatusChip from "../../components/leads/StatusChip";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import Spinner from "../../components/ui/Spinner";
import { useApi } from "../../hooks/useApi";
import { useAuth } from "../../hooks/useAuth";
import { cn } from "../../lib/cn";
import type { LeadDetail, MessageList } from "../../types/lead";

export default function LeadsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const selectedId = useParams()["*"] || undefined;
  const isAdmin = user?.role === "admin" || user?.role === "owner";

  // Filters
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [hotOnly, setHotOnly] = useState(false);
  const [assigned, setAssigned] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setQ(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const leads = useApi(
    () => listLeads({
      q, status, limit: 100,
      score_min: hotOnly ? 70 : undefined,
      assigned_to: isAdmin ? assigned : undefined,
    }),
    [q, status, hotOnly, assigned, isAdmin],
    15000,
  );

  const detail = useApi<LeadDetail | null>(
    () => (selectedId ? getLead(selectedId) : Promise.resolve(null)),
    [selectedId], 15000,
  );
  // While a different lead is still loading, show nothing rather than the previous lead,
  // so a reply can never be sent to the wrong conversation.
  const lead = detail.data && detail.data.id === selectedId ? detail.data : null;
  const conversationId = lead?.conversations[0]?.id;
  const messages = useApi<MessageList | null>(
    () => (conversationId ? listMessages(conversationId) : Promise.resolve(null)),
    [conversationId], 5000,
  );
  const thread = messages.data && messages.data.conversation_id === conversationId ? messages.data : null;

  const convStatus = thread?.status ?? lead?.conversations[0]?.status;
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  function refreshAll() {
    leads.reload(true);
    detail.reload(true);
    messages.reload(true);
  }

  async function act(fn: (id: string) => Promise<unknown>) {
    if (!conversationId) return;
    setBusy(true);
    setActionError(null);
    try {
      await fn(conversationId);
      refreshAll();
    } catch (e) {
      setActionError(errorText(e));
    } finally {
      setBusy(false);
    }
  }

  async function send(text: string, clientMessageId: string) {
    if (!conversationId) return;
    await sendMessage(conversationId, text, clientMessageId);
    messages.reload(true);
    leads.reload(true);
  }

  const humanMode = convStatus === "human";

  return (
    <div className="flex h-full min-h-0">
      {/* Lead list */}
      <section className={cn(
        "min-h-0 w-full shrink-0 flex-col border-r border-charcoal-200 bg-white md:w-80 lg:w-96",
        selectedId ? "hidden md:flex" : "flex",
      )}>
        <div className="space-y-2 border-b border-charcoal-200 p-3">
          <Input placeholder="Search name or phone" aria-label="Search leads"
            value={search} onChange={(e) => setSearch(e.target.value)} />
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <select aria-label="Filter by who is handling" value={status} onChange={(e) => setStatus(e.target.value)}
              className="h-9 rounded-md border border-charcoal-200 bg-white px-2">
              <option value="">All chats</option>
              <option value="agent">AI handling</option>
              <option value="human">Human handling</option>
            </select>
            {isAdmin && (
              <select aria-label="Filter by assignment" value={assigned} onChange={(e) => setAssigned(e.target.value)}
                className="h-9 rounded-md border border-charcoal-200 bg-white px-2">
                <option value="">Everyone's leads</option>
                <option value="me">Mine</option>
                <option value="none">Unassigned</option>
              </select>
            )}
            <label className="flex items-center gap-1">
              <input type="checkbox" checked={hotOnly} onChange={(e) => setHotOnly(e.target.checked)} />
              Hot only
            </label>
          </div>
          {leads.data && <p className="text-xs text-charcoal-600">{leads.data.total} lead{leads.data.total === 1 ? "" : "s"}</p>}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto">
          <LeadList
            items={leads.data?.items ?? []}
            loading={leads.loading}
            error={leads.error}
            selectedId={selectedId}
            onSelect={(id) => navigate(`/leads/${id}`)}
          />
        </div>
      </section>

      {/* Chat */}
      <section className={cn("min-h-0 min-w-0 flex-1 flex-col", selectedId ? "flex" : "hidden md:flex")}>
        {!selectedId && (
          <div className="flex flex-1 items-center justify-center p-6 text-center text-sm text-charcoal-600">
            Pick a lead to read the conversation.
          </div>
        )}

        {selectedId && detail.loading && !lead && <Spinner label="Loading conversation" />}
        {selectedId && detail.error && !lead && (
          <div className="p-6 text-sm">
            <p role="alert" className="text-danger">{detail.error}</p>
            <Button variant="secondary" className="mt-3" onClick={() => navigate("/leads")}>Back to leads</Button>
          </div>
        )}

        {selectedId && lead && (
          <>
            <header className="flex flex-wrap items-center gap-3 border-b border-charcoal-200 bg-white px-4 py-3">
              <Button variant="ghost" className="h-8 px-2 md:hidden" onClick={() => navigate("/leads")}>Back</Button>
              <div className="min-w-0 flex-1">
                <h1 className="truncate font-semibold">{lead.name || lead.phone}</h1>
                <p className="truncate text-xs text-charcoal-600">{lead.phone}</p>
              </div>
              <StatusChip status={convStatus} />
              <TakeOverButton
                status={convStatus} busy={busy}
                onTakeOver={() => act(takeover)} onRelease={() => act(release)}
              />
            </header>
            {actionError && <p role="alert" className="bg-red-50 px-4 py-2 text-sm text-danger">{actionError}</p>}
            <HandoffBanner handoffs={lead.open_handoffs} />
            <details className="border-b border-charcoal-200 bg-white xl:hidden">
              <summary className="cursor-pointer px-4 py-2 text-sm font-medium">Customer details</summary>
              <ContactProfile lead={lead} />
            </details>
            {messages.error && !thread && <p role="alert" className="p-4 text-sm text-danger">{messages.error}</p>}
            <ChatThread messages={thread?.items ?? []} />
            <Composer
              enabled={humanMode}
              hint="Take over this conversation to reply."
              onSend={send}
            />
          </>
        )}
      </section>

      {/* Customer details (wide screens) */}
      {selectedId && lead && (
        <aside className="hidden w-80 shrink-0 overflow-y-auto border-l border-charcoal-200 bg-white xl:block">
          <ContactProfile lead={lead} />
        </aside>
      )}
    </div>
  );
}
