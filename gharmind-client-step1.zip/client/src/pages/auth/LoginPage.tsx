import { QRCodeSVG } from "qrcode.react";
import { useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "react-router-dom";

import { login, mfaConfirm, mfaEnroll, mfaVerify } from "../../api/auth";
import { errorText } from "../../api/client";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import { useAuth } from "../../hooks/useAuth";

type Step =
  | { name: "password" }
  | { name: "code"; challenge: string }
  | { name: "setup"; enrollToken: string; secret: string; uri: string };

export default function LoginPage() {
  const { user, ready, signIn } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>({ name: "password" });
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (ready && user) return <Navigate to="/leads" replace />;

  async function run(action: () => Promise<void>) {
    setBusy(true);
    setError(null);
    try {
      await action();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  }

  function startOver() {
    setStep({ name: "password" });
    setPassword("");
    setCode("");
    setError(null);
  }

  function submitPassword(e: FormEvent) {
    e.preventDefault();
    run(async () => {
      const r = await login(email.trim(), password);
      if (r.mfa_enrolled) {
        setStep({ name: "code", challenge: r.challenge_token });
      } else {
        const s = await mfaEnroll(r.challenge_token);
        setStep({ name: "setup", enrollToken: s.enroll_token, secret: s.secret, uri: s.otpauth_uri });
      }
      setPassword("");
    });
  }

  function submitCode(e: FormEvent) {
    e.preventDefault();
    if (step.name === "password") return;
    const clean = code.replace(/\s/g, "");
    run(async () => {
      const resp = step.name === "code"
        ? await mfaVerify(step.challenge, clean)
        : await mfaConfirm(step.enrollToken, clean);
      signIn(resp);
      navigate("/leads", { replace: true });
    });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-charcoal-950 p-4">
      <div className="w-full max-w-sm rounded-lg bg-white p-6 shadow-lg">
        <div className="mb-5 flex items-center gap-2 text-lg font-semibold">
          <span className="inline-block h-3 w-3 rounded-full bg-brand-500" />
          Gharmind
        </div>

        {step.name === "password" && (
          <form onSubmit={submitPassword} className="space-y-4">
            <h1 className="text-xl font-semibold">Log in</h1>
            <Input label="Email" type="email" autoComplete="username" required
              value={email} onChange={(e) => setEmail(e.target.value)} />
            <Input label="Password" type="password" autoComplete="current-password" required
              value={password} onChange={(e) => setPassword(e.target.value)} />
            {error && <p role="alert" className="text-sm text-danger">{error}</p>}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Checking..." : "Continue"}
            </Button>
          </form>
        )}

        {step.name !== "password" && (
          <form onSubmit={submitCode} className="space-y-4">
            {step.name === "setup" ? (
              <>
                <h1 className="text-xl font-semibold">Set up your authenticator</h1>
                <p className="text-sm text-charcoal-600">
                  Scan this code with an authenticator app such as Google Authenticator, then enter
                  the 6-digit code it shows.
                </p>
                <div className="flex justify-center rounded-md border border-charcoal-200 bg-white p-3">
                  <QRCodeSVG value={step.uri} size={176} level="M" />
                </div>
                <p className="break-all text-center text-xs text-charcoal-600">
                  Can't scan? Enter this key by hand:<br />
                  <span className="font-mono text-charcoal-950">{step.secret}</span>
                </p>
              </>
            ) : (
              <>
                <h1 className="text-xl font-semibold">Enter your code</h1>
                <p className="text-sm text-charcoal-600">Open your authenticator app and enter the 6-digit code.</p>
              </>
            )}
            <Input label="6-digit code" inputMode="numeric" autoComplete="one-time-code"
              required maxLength={8} autoFocus value={code} onChange={(e) => setCode(e.target.value)} />
            {error && <p role="alert" className="text-sm text-danger">{error}</p>}
            <Button type="submit" className="w-full" disabled={busy || code.replace(/\s/g, "").length < 6}>
              {busy ? "Checking..." : step.name === "setup" ? "Finish setup" : "Log in"}
            </Button>
            <button type="button" onClick={startOver} className="w-full text-center text-sm text-charcoal-600 underline">
              Start over
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
