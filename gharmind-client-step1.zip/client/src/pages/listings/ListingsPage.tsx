export default function ListingsPage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="text-xl font-semibold">Listings</h1>
      <p className="mt-2 text-sm text-charcoal-600">The listings screen is built in the next step.</p>
    </div>
  );
}
