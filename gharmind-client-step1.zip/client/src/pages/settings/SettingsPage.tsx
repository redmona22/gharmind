export default function SettingsPage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="text-xl font-semibold">Team</h1>
      <p className="mt-2 text-sm text-charcoal-600">Team management and lead assignment are built in the next step.</p>
    </div>
  );
}
