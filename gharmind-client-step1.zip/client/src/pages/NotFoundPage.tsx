import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 p-6 text-center">
      <h1 className="text-xl font-semibold">Page not found</h1>
      <Link to="/leads" className="text-sm text-brand-text underline">Go to leads</Link>
    </div>
  );
}
