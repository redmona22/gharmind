import { useCallback, useEffect, useRef, useState } from "react";

import { errorText } from "../api/client";

/** Load data, optionally refresh it every `pollMs`. Ignores answers to outdated requests. */
export function useApi<T>(fetcher: () => Promise<T>, deps: unknown[], pollMs = 0) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const latest = useRef(0);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const reload = useCallback(async (silent = false) => {
    const mine = ++latest.current;
    if (!silent) setLoading(true);
    try {
      const result = await fetcher();
      if (mine !== latest.current) return;
      setData(result);
      setError(null);
    } catch (e) {
      if (mine !== latest.current) return;
      setError(errorText(e));
    } finally {
      if (mine === latest.current) setLoading(false);
    }
  }, deps);

  useEffect(() => {
    reload();
    if (!pollMs) return;
    const timer = setInterval(() => reload(true), pollMs);
    return () => clearInterval(timer);
  }, [reload, pollMs]);

  return { data, error, loading, reload };
}
