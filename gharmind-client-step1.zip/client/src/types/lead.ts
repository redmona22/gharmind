export type ConversationStatus = "agent" | "human" | "closed";

export interface LeadItem {
  id: string;
  name: string | null;
  phone: string;
  language: string;
  source: string | null;
  lead_score: number;
  consent_status: string;
  assigned_user_id: string | null;
  conversation_id: string | null;
  conversation_status: ConversationStatus | null;
  last_message: { sender: string; content: string; at: string } | null;
  created_at: string;
}

export interface LeadList {
  items: LeadItem[];
  total: number;
}

export interface OpenHandoff {
  id: string;
  conversation_id: string;
  reason: string;
  summary: string;
  created_at: string;
}

export interface LeadDetail {
  id: string;
  name: string | null;
  phone: string;
  language: string;
  source: string | null;
  lead_score: number;
  qualification: Record<string, string | number>;
  consent_status: string;
  assigned_user_id: string | null;
  conversations: { id: string; status: ConversationStatus; channel: string }[];
  open_handoffs: OpenHandoff[];
}

export interface ChatMessage {
  id: string;
  direction: "in" | "out";
  sender: "client" | "agent" | "human";
  content: string;
  tool_used: string | null;
  created_at: string;
}

export interface MessageList {
  conversation_id: string;
  status: ConversationStatus;
  items: ChatMessage[];
}
