export type Role = "owner" | "admin" | "salesperson";

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
}

export interface SessionResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  user: User;
}
