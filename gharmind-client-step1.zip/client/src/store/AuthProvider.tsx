import { createContext, useCallback, useEffect, useState, type ReactNode } from "react";

import { me } from "../api/auth";
import { setUnauthorizedHandler } from "../api/client";
import type { SessionResponse, User } from "../types/user";
import { clearSession, loadSession, saveSession } from "./authStore";

interface AuthContextValue {
  user: User | null;
  ready: boolean;
  signIn: (resp: SessionResponse) => void;
  signOut: () => void;
}

export const AuthContext = createContext<AuthContextValue>({
  user: null,
  ready: false,
  signIn: () => {},
  signOut: () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  const signOut = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const signIn = useCallback((resp: SessionResponse) => {
    saveSession({ token: resp.access_token, user: resp.user, expiresAt: Date.now() + resp.expires_in * 1000 });
    setUser(resp.user);
  }, []);

  // Any 401 from the API (expired token, switched-off account) logs the user out.
  useEffect(() => {
    setUnauthorizedHandler(signOut);
    return () => setUnauthorizedHandler(null);
  }, [signOut]);

  // On page load, restore the session and confirm it is still valid.
  useEffect(() => {
    const s = loadSession();
    if (!s) {
      setReady(true);
      return;
    }
    setUser(s.user);
    me()
      .then((u) => setUser(u))
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  return <AuthContext.Provider value={{ user, ready, signIn, signOut }}>{children}</AuthContext.Provider>;
}
