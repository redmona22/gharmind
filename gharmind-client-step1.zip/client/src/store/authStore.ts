import type { User } from "../types/user";

const KEY = "gharmind.session";

export interface Session {
  token: string;
  user: User;
  expiresAt: number; // ms since epoch
}

export function loadSession(): Session | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Session;
    return s.expiresAt > Date.now() ? s : null;
  } catch {
    return null;
  }
}

export function saveSession(s: Session): void {
  try {
    sessionStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable: the session just lasts until the page reloads */
  }
}

export function clearSession(): void {
  try {
    sessionStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function getToken(): string | null {
  return loadSession()?.token ?? null;
}
