import { Navigate, Outlet } from "react-router-dom";

import Spinner from "../components/ui/Spinner";
import { useAuth } from "../hooks/useAuth";
import type { Role } from "../types/user";

export default function ProtectedRoute({ roles }: { roles?: Role[] }) {
  const { user, ready } = useAuth();
  if (!ready) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/leads" replace />;
  return <Outlet />;
}
