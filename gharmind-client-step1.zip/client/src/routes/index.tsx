import { Navigate, Route, Routes } from "react-router-dom";

import AppShell from "../components/layout/AppShell";
import LoginPage from "../pages/auth/LoginPage";
import LeadsPage from "../pages/leads/LeadsPage";
import ListingsPage from "../pages/listings/ListingsPage";
import NotFoundPage from "../pages/NotFoundPage";
import SettingsPage from "../pages/settings/SettingsPage";
import ProtectedRoute from "./ProtectedRoute";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppShell />}>
          <Route path="/" element={<Navigate to="/leads" replace />} />
          <Route path="/leads/*" element={<LeadsPage />} />
          <Route path="/listings" element={<ListingsPage />} />
          <Route element={<ProtectedRoute roles={["admin", "owner"]} />}>
            <Route path="/team" element={<SettingsPage />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
