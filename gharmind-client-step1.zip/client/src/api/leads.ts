import type { LeadDetail, LeadList } from "../types/lead";
import { api } from "./client";

export interface LeadFilters {
  q?: string;
  status?: string;
  score_min?: number;
  assigned_to?: string;
  limit?: number;
}

export function listLeads(filters: LeadFilters) {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(filters)) {
    if (v !== undefined && v !== "") params.set(k, String(v));
  }
  const qs = params.toString();
  return api<LeadList>(`/leads${qs ? `?${qs}` : ""}`);
}

export const getLead = (id: string) => api<LeadDetail>(`/leads/${id}`);
