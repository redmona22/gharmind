import type { SessionResponse, User } from "../types/user";
import { api } from "./client";

export const login = (email: string, password: string) =>
  api<{ challenge_token: string; mfa_enrolled: boolean }>("/auth/login", {
    method: "POST", body: { email, password }, auth: false,
  });

export const mfaVerify = (challenge_token: string, code: string) =>
  api<SessionResponse>("/auth/mfa/verify", {
    method: "POST", body: { challenge_token, code }, auth: false,
  });

export const mfaEnroll = (challenge_token: string) =>
  api<{ enroll_token: string; secret: string; otpauth_uri: string }>("/auth/mfa/enroll", {
    method: "POST", body: { challenge_token }, auth: false,
  });

export const mfaConfirm = (enroll_token: string, code: string) =>
  api<SessionResponse>("/auth/mfa/confirm", {
    method: "POST", body: { enroll_token, code }, auth: false,
  });

export const me = () => api<User>("/auth/me");
