import type { MessageList } from "../types/lead";
import { api } from "./client";

export const listMessages = (conversationId: string) =>
  api<MessageList>(`/conversations/${conversationId}/messages`);

export const takeover = (conversationId: string) =>
  api<{ status: string }>(`/conversations/${conversationId}/takeover`, { method: "POST" });

export const release = (conversationId: string) =>
  api<{ status: string }>(`/conversations/${conversationId}/release`, { method: "POST" });

export const sendMessage = (conversationId: string, text: string, clientMessageId: string) =>
  api<{ message_id: string }>(`/conversations/${conversationId}/messages`, {
    method: "POST", body: { text, client_message_id: clientMessageId },
  });
