/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        charcoal: {
          50: "#F5F6F8",
          200: "#D5D8DD",
          400: "#8A919C",
          600: "#4A505A",
          800: "#262A31",
          900: "#1C1F24",
          950: "#14161A",
        },
        brand: { 100: "#FFEDD5", 500: "#F97316", 600: "#EA580C", text: "#C2410C" },
        success: "#16A34A",
        warning: "#F59E0B",
        danger: "#DC2626",
        info: "#2563EB",
      },
      fontFamily: {
        // Windows shows Hindi and Odia through Nirmala UI automatically.
        sans: ["Inter", "Noto Sans Devanagari", "Noto Sans Oriya", "Nirmala UI", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
